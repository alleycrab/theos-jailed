// https://gist.github.com/markd2/5961219
#import <Foundation/Foundation.h>
 
// Returns an array of names of the types.
NSArray *ParseTypeString (NSString *typeString);
